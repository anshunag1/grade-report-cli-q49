#!/usr/bin/env node
'use strict';
const fs = require('fs');
const { Command } = require('commander');
const { parseMarks, buildReport, gradeDistribution, sortStudents, toCsv } = require('./lib');

const useColor = process.stdout.isTTY && !process.env.NO_COLOR && !process.argv.includes('--no-color');
const paint = (code, txt) => (useColor ? `\x1b[${code}m${txt}\x1b[0m` : txt);
const green = (t) => paint(32, t);
const red = (t) => paint(31, t);
const bold = (t) => paint(1, t);

const program = new Command();
program
  .name('grade-report')
  .description('Read a CSV of student marks and print a grade report with averages and toppers')
  .version('1.0.0')
  .argument('<file>', 'path to marks CSV (first column = student name, other columns = subjects)')
  .option('-t, --top <n>', 'number of toppers to list', '3')
  .option('-p, --pass-mark <n>', 'minimum marks needed in every subject to pass', '40')
  .option('-s, --sort <by>', 'sort order: total, avg or name', 'total')
  .option('-e, --export <file>', 'also save the student table as a CSV file')
  .option('-j, --json', 'print the report as JSON instead of tables')
  .option('--no-color', 'disable coloured output')
  .action((file, opts) => {
    try {
      if (!fs.existsSync(file)) throw new Error(`File not found: ${file}`);
      const top = Number(opts.top);
      const pass = Number(opts.passMark);
      if (!Number.isInteger(top) || top < 1) throw new Error('--top must be a positive whole number.');
      if (Number.isNaN(pass) || pass < 0 || pass > 100) throw new Error('--pass-mark must be between 0 and 100.');

      if (!['total', 'avg', 'name'].includes(opts.sort)) throw new Error('--sort must be total, avg or name.');

      const report = buildReport(parseMarks(fs.readFileSync(file, 'utf8')), pass);
      const shown = sortStudents(report.students, opts.sort);

      if (opts.export) {
        fs.writeFileSync(opts.export, toCsv(report));
        console.log(green(`Report exported to ${opts.export}`));
      }

      if (opts.json) { console.log(JSON.stringify(report, null, 2)); return; }

      console.log(bold('\n=== STUDENT GRADE REPORT ==='));
      console.table(shown.map((s) => ({
        Rank: s.rank, Name: s.name, Total: s.total, 'Avg %': s.average, Grade: s.grade, Result: s.result,
      })));

      console.log(bold('=== SUBJECT SUMMARY ==='));
      console.table(report.subjectStats.map((s) => ({
        Subject: s.subject, Average: s.average, Highest: s.highest, Lowest: s.lowest, Topper: s.topper,
      })));

      console.log(bold(`=== TOP ${Math.min(top, report.students.length)} STUDENT(S) ===`));
      report.students.slice(0, top).forEach((s) =>
        console.log(`  ${s.rank}. ${s.name} - ${s.total} marks (${s.average}%, grade ${s.grade})`));

      console.log(bold('\n=== GRADE DISTRIBUTION ==='));
      Object.entries(gradeDistribution(report.students)).forEach(([g, n]) =>
        console.log(`  ${g.padEnd(2)} | ${'#'.repeat(n * 4)} ${n}`));

      console.log(bold('\n=== CLASS SUMMARY ==='));
      console.log(`  Students     : ${report.students.length}`);
      console.log(`  Class average: ${report.classAverage}%`);
      console.log(`  Passed       : ${green(report.passed)}   Failed: ${report.failed ? red(report.failed) : report.failed}  (pass mark ${report.passMark} per subject)\n`);
    } catch (err) {
      console.error(`Error: ${err.message}`);
      process.exit(1);
    }
  });

program.parse();
