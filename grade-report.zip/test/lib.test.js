const test = require('node:test');
const assert = require('node:assert');
const { gradeFor, parseMarks, buildReport, gradeDistribution, sortStudents, toCsv } = require('../lib');

const csv = 'name,maths,physics\nA,90,80\nB,30,70\nC,60,60\n';

test('gradeFor boundaries', () => {
  assert.strictEqual(gradeFor(90), 'A+');
  assert.strictEqual(gradeFor(89.99), 'A');
  assert.strictEqual(gradeFor(80), 'A');
  assert.strictEqual(gradeFor(70), 'B');
  assert.strictEqual(gradeFor(60), 'C');
  assert.strictEqual(gradeFor(50), 'D');
  assert.strictEqual(gradeFor(49.99), 'F');
});

test('totals, averages and ranking', () => {
  const r = buildReport(parseMarks(csv));
  assert.deepStrictEqual(r.students.map((s) => s.name), ['A', 'C', 'B']);
  assert.strictEqual(r.students[0].total, 170);
  assert.strictEqual(r.students[0].average, 85);
});

test('pass/fail uses per-subject pass mark', () => {
  const r = buildReport(parseMarks(csv), 40);
  assert.strictEqual(r.students.find((s) => s.name === 'B').result, 'FAIL');
  assert.strictEqual(r.passed, 2);
});

test('subject topper and class average', () => {
  const r = buildReport(parseMarks(csv));
  assert.strictEqual(r.subjectStats[0].topper, 'A');
  assert.strictEqual(r.subjectStats[0].highest, 90);
  assert.strictEqual(r.classAverage, 65);
});

test('rejects invalid marks', () => {
  assert.throws(() => parseMarks('name,maths\nA,abc\n'), /Invalid mark/);
  assert.throws(() => parseMarks('name,maths\nA,101\n'), /Invalid mark/);
  assert.throws(() => parseMarks('name,maths\nA,\n'), /Invalid mark/);
});

test('rejects empty input', () => {
  assert.throws(() => parseMarks('name,maths\n'), /no student rows/);
});

test('gradeDistribution counts each grade', () => {
  const r = buildReport(parseMarks(csv));
  const d = gradeDistribution(r.students);
  assert.strictEqual(d['A'], 1);   // A: 85
  assert.strictEqual(d['C'], 1);   // C: 60
  assert.strictEqual(d['D'], 1);   // B: 50
  assert.strictEqual(Object.values(d).reduce((a, b) => a + b, 0), 3);
});

test('sortStudents by name and avg', () => {
  const r = buildReport(parseMarks(csv));
  assert.deepStrictEqual(sortStudents(r.students, 'name').map((s) => s.name), ['A', 'B', 'C']);
  assert.deepStrictEqual(sortStudents(r.students, 'avg').map((s) => s.name), ['A', 'C', 'B']);
});

test('toCsv writes header and one line per student', () => {
  const r = buildReport(parseMarks(csv));
  const lines = toCsv(r).trim().split('\n');
  assert.strictEqual(lines.length, 4);
  assert.strictEqual(lines[0], 'Rank,Name,Total,Average,Grade,Result');
  assert.strictEqual(lines[1], '1,A,170,85,A,PASS');
});

test('toCsv escapes commas in names', () => {
  const r = buildReport(parseMarks('name,maths\n"Kumar, R",70\n'));
  assert.ok(toCsv(r).includes('"Kumar, R"'));
});
