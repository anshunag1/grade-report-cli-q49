# grade-report

Node.js CLI that reads a CSV of student marks and prints a grade report: ranks, totals, averages, grades, pass/fail, subject-wise statistics, toppers and class average.

## Install & run
    npm install
    node index.js marks.csv
    node index.js marks.csv --top 5 --pass-mark 50
    node index.js marks.csv --json
    npm test

## CSV format
First column = student name, remaining columns = subjects (marks 0-100).

## Publish to npm
`package.json` has a `bin` field and `index.js` starts with `#!/usr/bin/env node`. Run `npm login` then `npm publish`.
