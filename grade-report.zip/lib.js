'use strict';
const { parse } = require('csv-parse/sync');

/** Convert an average percentage to a letter grade. */
function gradeFor(avg) {
  if (avg >= 90) return 'A+';
  if (avg >= 80) return 'A';
  if (avg >= 70) return 'B';
  if (avg >= 60) return 'C';
  if (avg >= 50) return 'D';
  return 'F';
}

/** Parse CSV text into { nameCol, subjects, rows } and validate every mark. */
function parseMarks(csvText) {
  const rows = parse(csvText, { columns: true, skip_empty_lines: true, trim: true });
  if (rows.length === 0) throw new Error('CSV has no student rows.');
  const [nameCol, ...subjects] = Object.keys(rows[0]);
  if (subjects.length === 0) throw new Error('CSV needs at least one subject column.');
  rows.forEach((r, i) => {
    subjects.forEach((s) => {
      const v = Number(r[s]);
      if (r[s] === '' || Number.isNaN(v) || v < 0 || v > 100) {
        throw new Error(`Invalid mark "${r[s]}" for ${r[nameCol] || 'row ' + (i + 2)} in ${s} (must be 0-100).`);
      }
    });
  });
  return { nameCol, subjects, rows };
}

/** Build the full report: ranked students, subject stats, class average. */
function buildReport({ nameCol, subjects, rows }, passMark = 40) {
  const students = rows.map((r) => {
    const marks = subjects.map((s) => Number(r[s]));
    const total = marks.reduce((a, b) => a + b, 0);
    const average = +(total / subjects.length).toFixed(2);
    const failedIn = subjects.filter((s) => Number(r[s]) < passMark);
    return {
      name: r[nameCol], total, average,
      grade: gradeFor(average),
      result: failedIn.length === 0 ? 'PASS' : 'FAIL',
      failedIn,
    };
  }).sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));
  students.forEach((s, i) => { s.rank = i + 1; });

  const subjectStats = subjects.map((s) => {
    const vals = rows.map((r) => Number(r[s]));
    const topMark = Math.max(...vals);
    return {
      subject: s,
      average: +(vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(2),
      highest: topMark,
      lowest: Math.min(...vals),
      topper: rows.filter((r) => Number(r[s]) === topMark).map((r) => r[nameCol]).join(', '),
    };
  });

  const classAverage = +(students.reduce((a, s) => a + s.average, 0) / students.length).toFixed(2);
  const passed = students.filter((s) => s.result === 'PASS').length;
  return { students, subjectStats, classAverage, passed, failed: students.length - passed, passMark };
}

/** Count how many students got each grade (for the distribution chart). */
function gradeDistribution(students) {
  const dist = { 'A+': 0, A: 0, B: 0, C: 0, D: 0, F: 0 };
  students.forEach((s) => { dist[s.grade] += 1; });
  return dist;
}

/** Sort students by 'total' (default), 'avg' or 'name' and re-number the ranks. */
function sortStudents(students, by = 'total') {
  const copy = [...students];
  if (by === 'name') copy.sort((a, b) => a.name.localeCompare(b.name));
  else if (by === 'avg') copy.sort((a, b) => b.average - a.average);
  else copy.sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));
  return copy;
}

/** Turn the report into CSV text so it can be opened in Excel. */
function toCsv(report) {
  const esc = (v) => (/[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
  const head = ['Rank', 'Name', 'Total', 'Average', 'Grade', 'Result'];
  const lines = [head.join(',')];
  report.students.forEach((s) => lines.push([s.rank, s.name, s.total, s.average, s.grade, s.result].map(esc).join(',')));
  return lines.join('\n') + '\n';
}

module.exports = { gradeFor, parseMarks, buildReport, gradeDistribution, sortStudents, toCsv };
